<?php
/**
 * Plugin Name: WP Smart SEO Fixer
 * Plugin URI: https://example.com
 * Description: SEO issues scan aur fix karta hai.
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://example.com
 * License: GPL-2.0+
 * Text Domain: wp-smart-seo-fixer
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'WPSSF_VERSION', '1.0.0' );
define( 'WPSSF_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'WPSSF_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

require_once WPSSF_PLUGIN_DIR . 'includes/class-wp-smart-seo-fixer.php';

function run_wp_smart_seo_fixer() {
    $plugin = new WP_Smart_SEO_Fixer();
    $plugin->run();
}
add_action( 'plugins_loaded', 'run_wp_smart_seo_fixer' );