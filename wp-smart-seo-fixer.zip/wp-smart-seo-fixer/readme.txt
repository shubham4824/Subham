=== WP Smart SEO Fixer ===
Contributors: Subham rajput 
Tags: seo, optimization, audit, fixer
Requires at least: 5.0
Tested up to: 6.6
Stable tag: 1.0.0
License: GPLv2 or later

A WordPress plugin to audit SEO issues and provide 1-click fixes.

== Description ==
WP Smart SEO Fixer scans your site for SEO issues like missing ALT tags, meta titles, H1 tags, broken links, and more. Fix them with one click.

== Installation ==
1. Upload the `wp-smart-seo-fixer` folder to `/wp-content/plugins/`.
2. Activate the plugin in WordPress.
3. Go to 'SEO Fixer' menu to scan and fix issues.

== Changelog ==
= 1.0.0 =
* Initial release.