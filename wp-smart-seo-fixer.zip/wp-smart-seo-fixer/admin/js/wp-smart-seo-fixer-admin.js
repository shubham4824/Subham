jQuery(document).ready(function($) {
    $('#wpssf-scan-button').on('click', function() {
        $.ajax({
            url: wpssf_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'wpssf_scan_site',
                nonce: wpssf_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    $('#wpssf-results').html(renderResults(response.data));
                } else {
                    alert('Error scanning site.');
                }
            }
        });
    });

    $(document).on('click', '.wpssf-fix-button', function() {
        var issueType = $(this).data('issue-type');
        var postId = $(this).data('post-id');

        $.ajax({
            url: wpssf_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'wpssf_fix_issue',
                issue_type: issueType,
                post_id: postId,
                nonce: wpssf_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert(response.data.message);
                    $('#wpssf-scan-button').trigger('click');
                } else {
                    alert('Error fixing issue: ' + response.data.message);
                }
            }
        });
    });

    function renderResults(data) {
        var html = '<table class="wpssf-results-table">';
        html += '<tr><th>Issue Type</th><th>Post/Page</th><th>Details</th><th>Action</th></tr>';

        for (var issueType in data) {
            data[issueType].forEach(function(item) {
                var postTitle = item.post_id ? 'Post ID: ' + item.post_id : 'N/A';
                var details = '';

                if (issueType === 'missing_alt') {
                    details = 'Image: ' + item.img_tag;
                } else if (issueType === 'missing_meta') {
                    details = 'Title: ' + item.title + ', Description: ' + item.desc;
                } else if (issueType === 'broken_links') {
                    details = 'URL: ' + item.url;
                } else if (issueType === 'unfriendly_images') {
                    details = 'Filename: ' + item.filename;
                }

                html += '<tr>';
                html += '<td>' + issueType.replace(/_/g, ' ') + '</td>';
                html += '<td>' + postTitle + '</td>';
                html += '<td>' + details + '</td>';
                html += '<td><button class="wpssf-fix-button" data-issue-type="' + issueType + '" data-post-id="' + item.post_id + '">Fix Now</button></td>';
                html += '</tr>';
            });
        }

        html += '</table>';
        return html;
    }
});