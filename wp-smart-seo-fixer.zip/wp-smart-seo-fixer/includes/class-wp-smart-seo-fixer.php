<?php
class WP_Smart_SEO_Fixer {
    protected $version = WPSSF_VERSION;

    public function __construct() {
        $this->load_dependencies();
        $this->register_hooks();
    }

    private function load_dependencies() {
        require_once WPSSF_PLUGIN_DIR . 'includes/class-wp-smart-seo-fixer-scanner.php';
        require_once WPSSF_PLUGIN_DIR . 'includes/class-wp-smart-seo-fixer-fixer.php';
    }

    private function register_hooks() {
        add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
        add_action( 'wp_ajax_wpssf_scan_site', array( $this, 'ajax_scan_site' ) );
        add_action( 'wp_ajax_wpssf_fix_issue', array( $this, 'ajax_fix_issue' ) );
    }

    public function add_admin_menu() {
        add_menu_page(
            'WP Smart SEO Fixer',
            'SEO Fixer',
            'manage_options',
            'wp-smart-seo-fixer',
            array( $this, 'render_admin_page' ),
            'dashicons-search',
            80
        );
    }

    public function render_admin_page() {
        require_once WPSSF_PLUGIN_DIR . 'admin/partials/wp-smart-seo-fixer-admin-display.php';
    }

    public function enqueue_admin_scripts( $hook ) {
        if ( 'toplevel_page_wp-smart-seo-fixer' !== $hook ) {
            return;
        }

        wp_enqueue_style(
            'wpssf-admin-css',
            WPSSF_PLUGIN_URL . 'admin/css/wp-smart-seo-fixer-admin.css',
            array(),
            $this->version
        );

        wp_enqueue_script(
            'wpssf-admin-js',
            WPSSF_PLUGIN_URL . 'admin/js/wp-smart-seo-fixer-admin.js',
            array( 'jquery' ),
            $this->version,
            true
        );

        wp_localize_script(
            'wpssf-admin-js',
            'wpssf_ajax',
            array(
                'ajax_url' => admin_url( 'admin-ajax.php' ),
                'nonce'    => wp_create_nonce( 'wpssf_nonce' ),
            )
        );
    }

    public function ajax_scan_site() {
        check_ajax_referer( 'wpssf_nonce', 'nonce' );
        $scanner = new WP_Smart_SEO_Fixer_Scanner();
        $results = $scanner->scan_site();
        wp_send_json_success( $results );
    }

    public function ajax_fix_issue() {
        check_ajax_referer( 'wpssf_nonce', 'nonce' );
        $issue_type = sanitize_text_field( $_POST['issue_type'] );
        $post_id = intval( $_POST['post_id'] );
        $fixer = new WP_Smart_SEO_Fixer_Fixer();
        $result = $fixer->fix_issue( $issue_type, $post_id );
        wp_send_json_success( $result );
    }

    public function run() {}
}