<?php
class WP_Smart_SEO_Fixer_Fixer {
    public function fix_issue( $issue_type, $post_id ) {
        $result = array(
            'success' => false,
            'message' => '',
        );

        switch ( $issue_type ) {
            case 'missing_alt':
                $result = $this->fix_missing_alt( $post_id );
                break;
            case 'missing_meta':
                $result = $this->fix_missing_meta( $post_id );
                break;
            case 'missing_h1':
                $result = $this->fix_missing_h1( $post_id );
                break;
            case 'broken_links':
                $result = $this->fix_broken_links( $post_id );
                break;
            case 'unfriendly_images':
                $result = $this->fix_unfriendly_images( $post_id );
                break;
            default:
                $result['message'] = 'Invalid issue type.';
        }

        delete_transient( 'wpssf_seo_scan_results' );
        return $result;
    }

    private function fix_missing_alt( $post_id ) {
        $post = get_post( $post_id );
        $content = $post->post_content;

        preg_match_all( '/<img[^>]+>/i', $content, $images );
        foreach ( $images[0] as $img ) {
            if ( ! preg_match( '/alt=["\'][^"\']*["\']/i', $img ) ) {
                preg_match( '/src=["\'](.*?)["\']/i', $img, $src );
                $filename = basename( $src[1] );
                $alt_text = str_replace( '-', ' ', pathinfo( $filename, PATHINFO_FILENAME ) );
                $new_img = str_replace( '>', ' alt="' . esc_attr( $alt_text ) . '">', $img );
                $content = str_replace( $img, $new_img, $content );
            }
        }

        wp_update_post( array(
            'ID'           => $post_id,
            'post_content' => $content,
        ) );

        return array(
            'success' => true,
            'message' => 'Missing ALT tags fixed.',
        );
    }

    private function fix_missing_meta( $post_id ) {
        $post = get_post( $post_id );
        $title = get_post_meta( $post_id, '_yoast_wpseo_title', true ) ?: get_post_meta( $post_id, 'rank_math_title', true );
        $desc  = get_post_meta( $post_id, '_yoast_wpseo_metadesc', true ) ?: get_post_meta( $post_id, 'rank_math_description', true );

        if ( empty( $title ) ) {
            $title = wp_trim_words( $post->post_title, 10 );
            update_post_meta( $post_id, '_yoast_wpseo_title', $title );
            update_post_meta( $post_id, 'rank_math_title', $title );
        }

        if ( empty( $desc ) ) {
            $desc = wp_trim_words( strip_tags( $post->post_content ), 25 );
            update_post_meta( $post_id, '_yoast_wpseo_metadesc', $desc );
            update_post_meta( $post_id, 'rank_math_description', $desc );
        }

        return array(
            'success' => true,
            'message' => 'Missing meta tags fixed.',
        );
    }

    private function fix_missing_h1( $post_id ) {
        $post = get_post( $post_id );
        $content = $post->post_content;

        if ( ! preg_match( '/<h1[^>]*>.*?<\/h1>/i', $content ) ) {
            $h1 = '<h1>' . esc_html( $post->post_title ) . '</h1>';
            $content = $h1 . $content;

            wp_update_post( array(
                'ID'           => $post_id,
                'post_content' => $content,
            ) );
        }

        return array(
            'success' => true,
            'message' => 'Missing H1 tag added.',
        );
    }

    private function fix_broken_links( $post_id ) {
        $post = get_post( $post_id );
        $content = $post->post_content;

        preg_match_all( '/<a[^>]+href=["\'](.*?)["\']/i', $content, $links );
        foreach ( $links[1] as $index => $link ) {
            $response = wp_remote_head( $link );
            if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) >= 400 ) {
                $full_link = $links[0][ $index ];
                preg_match( '/>(.*?)</', $full_link, $link_text );
                $content = str_replace( $full_link, $link_text[1], $content );
            }
        }

        wp_update_post( array(
            'ID'           => $post_id,
            'post_content' => $content,
        ) );

        return array(
            'success' => true,
            'message' => 'Broken links removed.',
        );
    }

    private function fix_unfriendly_images( $post_id ) {
        return array(
            'success' => false,
            'message' => 'Please rename images manually in the Media Library.',
        );
    }
}